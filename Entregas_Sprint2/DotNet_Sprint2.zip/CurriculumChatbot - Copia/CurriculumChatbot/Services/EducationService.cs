﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CurriculumManagement.Models;
using CurriculumManagement.Repositories;

namespace CurriculumManagement.Services
{
    public class EducationService
    {
        private readonly IEducationRepository _repository;

        public EducationService(IEducationRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Education>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Education> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task AddAsync(Education education)
        {
            await _repository.AddAsync(education);
        }

        public async Task UpdateAsync(Education education)
        {
            await _repository.UpdateAsync(education);
        }

        public async Task DeleteAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}