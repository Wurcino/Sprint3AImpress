﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CurriculumChatbot.Models;
using CurriculumManagement.Models;
using CurriculumManagement.Repositories;

namespace CurriculumManagement.Services
{
    public class CurriculumService
    {
        private readonly ICurriculumRepository _repository;

        public CurriculumService(ICurriculumRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Curriculum>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Curriculum> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task AddAsync(Curriculum curriculum)
        {
            await _repository.AddAsync(curriculum);
        }

        public async Task UpdateAsync(Curriculum curriculum)
        {
            await _repository.UpdateAsync(curriculum);
        }

        public async Task DeleteAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}
