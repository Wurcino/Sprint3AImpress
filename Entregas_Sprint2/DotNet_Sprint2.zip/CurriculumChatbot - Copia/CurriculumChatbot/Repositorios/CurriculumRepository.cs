﻿using Microsoft.EntityFrameworkCore;
using CurriculumManagement.Data;
using CurriculumManagement.Models;
using CurriculumChatbot.Models;

namespace CurriculumManagement.Repositories
{
    public class CurriculumRepository : ICurriculumRepository
    {
        private readonly ApplicationDbContext _context;

        public CurriculumRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Curriculum>> GetAllAsync()
        {
            return await _context.Curriculums.Include(c => c.JobExperiences).Include(c => c.Educations).ToListAsync();
        }

        public async Task<Curriculum> GetByIdAsync(int id)
        {
            return await _context.Curriculums.Include(c => c.JobExperiences).Include(c => c.Educations).FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task AddAsync(Curriculum curriculum)
        {
            _context.Curriculums.Add(curriculum);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Curriculum curriculum)
        {
            _context.Entry(curriculum).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var curriculum = await _context.Curriculums.FindAsync(id);
            if (curriculum != null)
            {
                _context.Curriculums.Remove(curriculum);
                await _context.SaveChangesAsync();
            }
        }
    }
}
