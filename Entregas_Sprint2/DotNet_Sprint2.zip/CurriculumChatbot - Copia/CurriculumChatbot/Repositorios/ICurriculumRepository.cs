﻿using CurriculumChatbot.Models;
using CurriculumManagement.Models;

namespace CurriculumManagement.Repositories
{
    public interface ICurriculumRepository
    {
        Task<IEnumerable<Curriculum>> GetAllAsync();
        Task<Curriculum> GetByIdAsync(int id);
        Task AddAsync(Curriculum curriculum);
        Task UpdateAsync(Curriculum curriculum);
        Task DeleteAsync(int id);
    }
}
