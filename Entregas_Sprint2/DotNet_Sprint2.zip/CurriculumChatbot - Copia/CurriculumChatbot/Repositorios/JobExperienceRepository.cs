﻿using Microsoft.EntityFrameworkCore;
using CurriculumManagement.Data;
using CurriculumManagement.Models;

namespace CurriculumManagement.Repositories
{
    public class JobExperienceRepository : IJobExperienceRepository
    {
        private readonly ApplicationDbContext _context;

        public JobExperienceRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<JobExperience>> GetAllAsync()
        {
            return await _context.JobExperiences.ToListAsync();
        }

        public async Task<JobExperience> GetByIdAsync(int id)
        {
            return await _context.JobExperiences.FindAsync(id);
        }

        public async Task AddAsync(JobExperience jobExperience)
        {
            _context.JobExperiences.Add(jobExperience);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(JobExperience jobExperience)
        {
            _context.Entry(jobExperience).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var jobExperience = await _context.JobExperiences.FindAsync(id);
            if (jobExperience != null)
            {
                _context.JobExperiences.Remove(jobExperience);
                await _context.SaveChangesAsync();
            }
        }
    }
}
