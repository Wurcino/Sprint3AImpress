﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CurriculumManagement.Models;
using CurriculumManagement.Services;
using CurriculumChatbot.Models;

namespace CurriculumManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurriculumController : ControllerBase
    {
        private readonly CurriculumService _service;

        public CurriculumController(CurriculumService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Curriculum>>> GetCurriculums()
        {
            var curriculums = await _service.GetAllAsync();
            return Ok(curriculums);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Curriculum>> GetCurriculum(int id)
        {
            var curriculum = await _service.GetByIdAsync(id);
            if (curriculum == null)
            {
                return NotFound();
            }
            return Ok(curriculum);
        }

        [HttpPost]
        public async Task<ActionResult<Curriculum>> PostCurriculum(Curriculum curriculum)
        {
            await _service.AddAsync(curriculum);
            return CreatedAtAction(nameof(GetCurriculum), new { id = curriculum.Id }, curriculum);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutCurriculum(int id, Curriculum curriculum)
        {
            if (id != curriculum.Id)
            {
                return BadRequest();
            }

            await _service.UpdateAsync(curriculum);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCurriculum(int id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }
    }
}
