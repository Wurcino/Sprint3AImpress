﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CurriculumManagement.Models;
using CurriculumManagement.Services;

namespace CurriculumManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobExperienceController : ControllerBase
    {
        private readonly JobExperienceService _service;

        public JobExperienceController(JobExperienceService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<JobExperience>>> GetJobExperiences()
        {
            var jobExperiences = await _service.GetAllAsync();
            return Ok(jobExperiences);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<JobExperience>> GetJobExperience(int id)
        {
            var jobExperience = await _service.GetByIdAsync(id);
            if (jobExperience == null)
            {
                return NotFound();
            }
            return Ok(jobExperience);
        }

        [HttpPost]
        public async Task<ActionResult<JobExperience>> PostJobExperience(JobExperience jobExperience)
        {
            await _service.AddAsync(jobExperience);
            return CreatedAtAction(nameof(GetJobExperience), new { id = jobExperience.Id }, jobExperience);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutJobExperience(int id, JobExperience jobExperience)
        {
            if (id != jobExperience.Id)
            {
                return BadRequest();
            }

            await _service.UpdateAsync(jobExperience);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteJobExperience(int id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }
    }
}
